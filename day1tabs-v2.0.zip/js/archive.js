// ============================================================
// day1tabs Archive Page Logic
// ============================================================

let archiveData = null;
let currentDate = null;

document.addEventListener('DOMContentLoaded', init);

async function init() {
  // Load archive
  const result = await sendMessage({ action: 'getArchive' });
  const archive = result.archive || [];

  // Check undo status
  const status = await sendMessage({ action: 'getStatus' });

  if (archive.length === 0 || !archive[0] || archive[0].tabs.length === 0) {
    document.getElementById('emptyState').style.display = 'block';
    document.getElementById('archiveContent').style.display = 'none';
    setupUndoButton(status);
    return;
  }

  archiveData = archive[0]; // Most recent day
  currentDate = archiveData.date;

  document.getElementById('emptyState').style.display = 'none';
  document.getElementById('archiveContent').style.display = 'block';

  // Show morning banner if opened from a reset
  showMorningBanner(status);

  // Show last reset date/time
  const resetDate = new Date(archiveData.timestamp);
  document.getElementById('resetTime').textContent = resetDate.toLocaleString(undefined, {
    weekday: 'short', month: 'short', day: 'numeric',
    hour: 'numeric', minute: '2-digit', hour12: true
  });

  renderStats(archiveData.stats);
  renderRamSavings(archiveData.stats);

  // Combine duplicates: from reset + auto-closed during the day
  const dupsClosed = archiveData.duplicatesClosed || result.duplicatesClosedToday || [];
  renderDuplicates(archiveData.duplicates || [], dupsClosed);
  renderGroups(archiveData.tabs);
  setupQuickActions();
  setupUndoButton(status);
  setupCollapsibleGroups();
  startNextCloseCountdown(status);
}

function renderStats(stats) {
  document.getElementById('statTotal').textContent = stats.total;
  document.getElementById('statWorkhorses').textContent = stats.workhorses;
  document.getElementById('statGlanced').textContent = stats.glanced;
  document.getElementById('statGhosts').textContent = stats.ghosts;

  const reopenedCount = stats.reopened || 0;
  const reopenedWrap = document.getElementById('statReopenedWrap');
  if (reopenedCount > 0) {
    reopenedWrap.style.display = '';
    document.getElementById('statReopened').textContent = reopenedCount;
  } else {
    reopenedWrap.style.display = 'none';
  }
}

const RAM_PER_TAB_MB = 100;

function renderRamSavings(stats) {
  const totalTabs = stats.total - (stats.reopened || 0);
  const totalMB = totalTabs * RAM_PER_TAB_MB;
  const workhorseMB = stats.workhorses * RAM_PER_TAB_MB;
  const glancedMB = stats.glanced * RAM_PER_TAB_MB;
  const ghostMB = stats.ghosts * RAM_PER_TAB_MB;

  document.getElementById('ramTotal').textContent = formatRAM(totalMB);

  const breakdown = document.getElementById('ramBreakdown');
  breakdown.innerHTML = '';

  const categories = [
    { label: 'Workhorses', cls: 'workhorse', mb: workhorseMB, count: stats.workhorses },
    { label: 'Glanced', cls: 'glanced', mb: glancedMB, count: stats.glanced },
    { label: 'Ghosts', cls: 'ghost', mb: ghostMB, count: stats.ghosts }
  ];

  for (const cat of categories) {
    if (cat.count === 0) continue;
    const el = document.createElement('div');
    el.className = 'ram-category';
    el.innerHTML = `
      <span class="ram-dot ${cat.cls}"></span>
      <span>${cat.label}:</span>
      <span class="ram-value">${formatRAM(cat.mb)}</span>
      <span>(${cat.count} tab${cat.count !== 1 ? 's' : ''})</span>
    `;
    breakdown.appendChild(el);
  }

  // Hide the whole section if nothing was freed
  document.getElementById('ramSavings').style.display = totalTabs > 0 ? '' : 'none';
}

function formatRAM(mb) {
  if (mb >= 1000) {
    return `~${(mb / 1000).toFixed(1)} GB`;
  }
  return `~${mb} MB`;
}

function renderDuplicates(duplicatesAtReset, duplicatesClosed) {
  const section = document.getElementById('duplicatesSection');
  const hasResetDups = duplicatesAtReset && duplicatesAtReset.length > 0;
  const hasClosedDups = duplicatesClosed && duplicatesClosed.length > 0;

  if (!hasResetDups && !hasClosedDups) {
    section.style.display = 'none';
    return;
  }

  section.style.display = 'block';

  // Wire up collapsible toggle
  document.getElementById('duplicatesToggle').addEventListener('click', () => {
    section.classList.toggle('expanded');
  });

  // Group closed duplicates by URL for display
  const closedByUrl = {};
  if (hasClosedDups) {
    for (const dup of duplicatesClosed) {
      if (!closedByUrl[dup.url]) {
        closedByUrl[dup.url] = { url: dup.url, title: dup.title, favIconUrl: dup.favIconUrl, count: 0 };
      }
      closedByUrl[dup.url].count++;
    }
  }
  const closedGroups = Object.values(closedByUrl);

  const totalCount = (duplicatesAtReset ? duplicatesAtReset.length : 0) + closedGroups.length;
  document.getElementById('duplicatesCount').textContent = totalCount;

  // Calculate total duplicate tabs closed/found and estimate RAM
  const totalDupTabs = (hasClosedDups ? duplicatesClosed.length : 0) +
    (hasResetDups ? duplicatesAtReset.reduce((sum, d) => sum + d.count - 1, 0) : 0);
  const dupRamMB = totalDupTabs * RAM_PER_TAB_MB;
  document.getElementById('duplicatesRam').textContent = `(⚡~${formatRAM(dupRamMB)} freed)`;

  const list = document.getElementById('duplicatesList');
  list.innerHTML = '';

  // Show auto-closed duplicates first (these are the valuable ones)
  if (hasClosedDups) {
    for (const dup of closedGroups) {
      const domain = extractDomain(dup.url);
      const item = document.createElement('div');
      item.className = 'duplicate-item auto-closed';
      item.innerHTML = `
        <div class="duplicate-info">
          <span class="duplicate-title">${escapeHtml(dup.title)}</span>
          <span class="duplicate-url">${escapeHtml(domain)}</span>
        </div>
        <span class="duplicate-badge">auto-closed</span>
        <span class="duplicate-count">${dup.count}×</span>
      `;
      list.appendChild(item);
    }
  }

  // Show duplicates found at reset
  if (hasResetDups) {
    for (const dup of duplicatesAtReset) {
      const domain = extractDomain(dup.url);
      const item = document.createElement('div');
      item.className = 'duplicate-item';
      item.innerHTML = `
        <div class="duplicate-info">
          <span class="duplicate-title">${escapeHtml(dup.title)}</span>
          <span class="duplicate-url">${escapeHtml(domain)}</span>
        </div>
        <span class="duplicate-count">${dup.count}×</span>
      `;
      list.appendChild(item);
    }
  }

  // Update hint based on what we have
  const hint = document.getElementById('duplicatesHint');
  if (hasClosedDups && !hasResetDups) {
    hint.textContent = `${duplicatesClosed.length} duplicate tab${duplicatesClosed.length !== 1 ? 's' : ''} auto-closed today. Less clutter, more focus.`;
  } else if (hasClosedDups && hasResetDups) {
    hint.textContent = `${duplicatesClosed.length} auto-closed during the day + ${duplicatesAtReset.length} found at reset. Duplicates are tab clutter.`;
  } else {
    hint.textContent = 'These pages were open multiple times. This is why you need fewer tabs.';
  }
}

function renderGroups(tabs) {
  const workhorses = tabs.filter((t, i) => { t._index = i; return t.classification === 'workhorse'; });
  const glanced = tabs.filter((t, i) => { t._index = i; return t.classification === 'glanced'; });
  const ghosts = tabs.filter((t, i) => { t._index = i; return t.classification === 'ghost'; });

  renderTabList('workhorseList', workhorses, 'workhorse');
  renderTabList('glancedList', glanced, 'glanced');
  renderTabList('ghostList', ghosts, 'ghost');

  document.getElementById('workhorseCount').textContent = workhorses.length;
  document.getElementById('glancedCount').textContent = glanced.length;
  document.getElementById('ghostCount').textContent = ghosts.length;

  // Hide empty groups or show empty message
  toggleGroupVisibility('groupWorkhorses', workhorses.length);
  toggleGroupVisibility('groupGlanced', glanced.length);
  toggleGroupVisibility('groupGhosts', ghosts.length);

  // Group reopen buttons
  document.querySelectorAll('.group-btn[data-action="reopen"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const group = btn.dataset.group;
      const urls = tabs.filter(t => t.classification === group && !t.reopened).map(t => t.url);
      if (urls.length === 0) {
        showToast('All tabs in this group already reopened');
        return;
      }
      await reopenTabs(urls);
      await refreshArchiveData();
      showToast(`Reopened ${urls.length} tab${urls.length !== 1 ? 's' : ''}`);
    });
  });
}

function renderTabList(containerId, tabs, classification) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';

  if (tabs.length === 0) {
    container.innerHTML = '<div class="empty-group-msg">No tabs in this category</div>';
    return;
  }

  tabs.forEach((tab) => {
    const isReopened = !!tab.reopened;
    const item = document.createElement('div');
    item.className = `tab-item ${classification}${isReopened ? ' reopened' : ''}`;
    item.dataset.index = tab._index;

    const focusStr = formatFocusTime(tab.focusTime);
    const activationStr = tab.activations === 1 ? '1 visit' : `${tab.activations} visits`;

    const domain = extractDomain(tab.url);
    const faviconHtml = tab.favIconUrl
      ? `<img class="tab-favicon" src="${escapeHtml(tab.favIconUrl)}" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
      : '';
    const placeholderHtml = `<div class="tab-favicon-placeholder" ${tab.favIconUrl ? 'style="display:none"' : ''}>${domain.charAt(0).toUpperCase()}</div>`;

    const reopenBtn = isReopened
      ? `<button class="tab-action-btn reopened-btn" disabled>Opened</button>`
      : `<button class="tab-action-btn reopen" data-url="${escapeAttr(tab.url)}" title="Reopen this tab">Open</button>`;

    const reopenedBadge = isReopened ? `<span class="tab-reopened-badge">Reopened</span>` : '';

    item.innerHTML = `
      ${faviconHtml}
      ${placeholderHtml}
      <div class="tab-info">
        <div class="tab-title">${escapeHtml(tab.title)}</div>
        <div class="tab-url">${escapeHtml(domain)}</div>
      </div>
      ${reopenedBadge}
      <div class="tab-meta">
        <span class="tab-stat">${activationStr}</span>
        <span class="tab-stat">${focusStr}</span>
      </div>
      <div class="tab-actions-wrap">
        <div class="tab-actions">
          ${reopenBtn}
          <button class="tab-action-btn reclassify-trigger" data-index="${tab._index}" title="Move to different group">Move</button>
        </div>
      </div>
    `;

    container.appendChild(item);
  });

  // Attach event listeners
  container.querySelectorAll('.reopen').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      await reopenTabs([btn.dataset.url]);
      await refreshArchiveData();
      showToast('Tab reopened');
    });
  });

  container.querySelectorAll('.reclassify-trigger').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      showReclassifyMenu(btn, parseInt(btn.dataset.index));
    });
  });
}

function showReclassifyMenu(trigger, tabIndex) {
  // Remove any existing menu
  document.querySelectorAll('.reclassify-menu').forEach(m => m.remove());

  const wrap = trigger.closest('.tab-actions-wrap');
  const currentClass = archiveData.tabs[tabIndex].classification;

  const menu = document.createElement('div');
  menu.className = 'reclassify-menu';

  const options = ['workhorse', 'glanced', 'ghost'].filter(c => c !== currentClass);

  options.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = 'reclassify-option';
    btn.innerHTML = `<span class="dot ${opt}"></span><span>${capitalize(opt)}</span>`;
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      await reclassifyTab(tabIndex, opt);
      menu.remove();
    });
    menu.appendChild(btn);
  });

  wrap.appendChild(menu);

  // Close on outside click
  const closeHandler = (e) => {
    if (!menu.contains(e.target)) {
      menu.remove();
      document.removeEventListener('click', closeHandler);
    }
  };
  setTimeout(() => document.addEventListener('click', closeHandler), 0);
}

async function reclassifyTab(tabIndex, newClassification) {
  await sendMessage({
    action: 'reclassifyTab',
    date: currentDate,
    tabIndex: tabIndex,
    newClassification: newClassification
  });

  // Refresh archive data
  const result = await sendMessage({ action: 'getArchive' });
  archiveData = result.archive[0];
  renderStats(archiveData.stats);
  renderGroups(archiveData.tabs);
  showToast(`Moved to ${capitalize(newClassification)}`);
}

function setupQuickActions() {
  document.getElementById('reopenWorkhorses').addEventListener('click', async () => {
    const urls = archiveData.tabs.filter(t => t.classification === 'workhorse' && !t.reopened).map(t => t.url);
    if (urls.length === 0) {
      showToast('No workhorse tabs to reopen');
      return;
    }
    await reopenTabs(urls);
    await refreshArchiveData();
    showToast(`Reopened ${urls.length} workhorse tab${urls.length !== 1 ? 's' : ''}`);
  });

  document.getElementById('reopenAll').addEventListener('click', async () => {
    const urls = archiveData.tabs.filter(t => !t.reopened).map(t => t.url);
    if (urls.length === 0) {
      showToast('All tabs already reopened');
      return;
    }
    await reopenTabs(urls);
    await refreshArchiveData();
    showToast(`Reopened ${urls.length} tab${urls.length !== 1 ? 's' : ''}`);
  });
}

function setupUndoButton(status) {
  const undoBtn = document.getElementById('undoAllBtn');

  if (status.undoAvailable) {
    undoBtn.style.display = 'flex';
    document.getElementById('undoCountdown').textContent = `${status.undoExpiresIn}m left`;

    undoBtn.addEventListener('click', async () => {
      const result = await sendMessage({ action: 'undo' });
      if (result.success) {
        undoBtn.style.display = 'none';
        await refreshArchiveData();
        showToast(`Restored ${result.count} tabs`);
      } else {
        showToast('Undo window has expired');
        undoBtn.style.display = 'none';
      }
    });

    // Update countdown
    setInterval(async () => {
      const s = await sendMessage({ action: 'getStatus' });
      if (s.undoAvailable) {
        document.getElementById('undoCountdown').textContent = `${s.undoExpiresIn}m left`;
      } else {
        undoBtn.style.display = 'none';
      }
    }, 60000);
  }
}

function toggleGroupVisibility(groupId, count) {
  const group = document.getElementById(groupId);
  if (count === 0) {
    group.classList.add('empty');
  } else {
    group.classList.remove('empty');
  }
}

function setupCollapsibleGroups() {
  document.querySelectorAll('.group-header[data-toggle]').forEach(header => {
    header.addEventListener('click', (e) => {
      // Don't toggle when clicking the "Reopen all" button
      if (e.target.closest('.group-btn')) return;

      const groupId = header.dataset.toggle;
      const group = document.getElementById(groupId);
      group.classList.toggle('expanded');
    });
  });
}

// ---- Helpers ----

async function refreshArchiveData() {
  const result = await sendMessage({ action: 'getArchive' });
  const archive = result.archive || [];
  if (archive.length > 0 && archive[0].tabs.length > 0) {
    archiveData = archive[0];
    renderStats(archiveData.stats);
    renderRamSavings(archiveData.stats);
    renderGroups(archiveData.tabs);
  }
}

async function reopenTabs(urls) {
  await sendMessage({ action: 'reopenTabs', urls });
}

function formatFocusTime(ms) {
  if (!ms || ms < 1000) return '<1s';
  const seconds = Math.round(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const remainingMins = minutes % 60;
  return `${hours}h ${remainingMins}m`;
}

function extractDomain(url) {
  try {
    return new URL(url).hostname.replace('www.', '');
  } catch {
    return url;
  }
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function escapeAttr(str) {
  return str.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function showToast(message) {
  // Remove existing
  document.querySelectorAll('.toast').forEach(t => t.remove());

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 2500);
}

function startNextCloseCountdown(status) {
  const el = document.getElementById('nextCloseText');
  const container = document.getElementById('nextClose');

  if (!status.resetEnabled) {
    el.textContent = 'Auto-close is paused';
    container.classList.add('disabled');
    return;
  }

  function update() {
    const now = new Date();
    const next = new Date(status.nextReset);

    // If next reset is in the past, add 24h
    if (next <= now) next.setDate(next.getDate() + 1);

    const diff = next - now;
    const hours = Math.floor(diff / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);

    if (hours > 0) {
      el.textContent = `Next auto-close in ${hours}h ${mins}m`;
    } else {
      el.textContent = `Next auto-close in ${mins}m`;
    }
  }

  update();
  setInterval(update, 60000);
}

function showMorningBanner(status) {
  const params = new URLSearchParams(window.location.search);
  const source = params.get('source');

  if (!source || !status.undoAvailable) return;

  const banner = document.getElementById('morningBanner');
  const text = document.getElementById('morningText');

  if (source === 'auto') {
    text.textContent = "Good morning — your browser is clean. Here's what was closed. Bring back what you need, let the rest go.";
  } else if (source === 'manual') {
    text.textContent = "Fresh start done. Here's what was closed. Bring back what you need, let the rest go.";
  } else {
    return;
  }

  banner.style.display = 'block';
}

function sendMessage(msg) {
  return chrome.runtime.sendMessage(msg);
}
